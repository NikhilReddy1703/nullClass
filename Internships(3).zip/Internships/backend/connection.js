const mongoose = require("mongoose");

const connectMongoDB = (url) => {
  mongoose.connect(url).then(() => console.log("MongoDB Connected..."));
};

module.exports = connectMongoDB;
