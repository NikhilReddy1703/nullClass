const express = require("express");
const router = express.Router();
const { getOtp, changePassword } = require("../controllers/otpCenter");

router.post("/", getOtp);

router.post("/change-password", changePassword);

//router.post("/verify", verifyOtp);

module.exports = router;
