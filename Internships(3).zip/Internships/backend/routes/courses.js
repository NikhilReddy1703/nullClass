const express = require("express");
const {
  verifyUserToken,
  verifyAdminToken,
} = require("../middlewares/verifyToken");
const router = express.Router();
const {
  getCourses,
  addCourses,
  editCourse,
} = require("../controllers/courses");
const { User, Courses } = require("../models");

router.get("/", getCourses);

router.post("/", verifyAdminToken, addCourses);

router.put("/:courseId", verifyAdminToken, editCourse);

router.post("/register", verifyUserToken, async (req, res) => {
  try {
    const { email } = req;
    const { selectedCourses, freeInternship } = req.body;

    if (freeInternship) {
      const user = await User.findOne({ email });

      if (user.freeProject === 0) {
        return res
          .status(200)
          .json({ message: "Free Courses limit completed." });
      }

      await User.updateOne(
        { email },
        {
          $addToSet: { registeredCourses: { $each: selectedCourses } },
          $set: { freeProject: 0 },
        }
      );

      return res
        .status(200)
        .json({ message: "Free course registered successfully" });
    }

    await User.updateOne(
      { email },
      { $addToSet: { registeredCourses: { $each: selectedCourses } } }
    );

    res.status(200).json({ message: "Courses registered successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/registered", verifyUserToken, async (req, res) => {
  try {
    const { email } = req;
    const { registeredCourses } = await User.findOne({ email });
    const courses = await Courses.find({ _id: { $in: registeredCourses } });
    res.status(200).json({ courses });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
