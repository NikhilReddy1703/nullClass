const express = require("express");
const { User } = require("../models");
const generateJwtToken = require("../middlewares/generateJwtToken");
const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { username, email } = req.body;

    let user = await User.findOne({ email });
    if (!user) {
      user = new User({ username, email, authProvider: "google" });
      await user.save();
    }

    const jwtToken = await generateJwtToken(email, "user");
    return res.status(200).json({ jwtToken });
  } catch (error) {
    console.error("Error saving user data:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

module.exports = router;
