const express = require("express");
const router = express.Router();

const loginRouter = require("./login");
const signupRouter = require("./signup");
const profileRouter = require("./profile");
const coursesRouter = require("./courses");
const googleLogin = require("./googleLogin");
const forgotPasswordRouter = require("./forgotPassword");

router.get("/", (req, res) => {
  res.json({ message: "Welcome to the NullClass API!" });
});

router.use("/login", loginRouter);
router.use("/signup", signupRouter);
router.use("/courses", coursesRouter);
router.use("/profile", profileRouter);
router.use("/google-login", googleLogin);
router.use("/forgot-password", forgotPasswordRouter);

module.exports = router;
