const express = require("express");
const { Admin, User } = require("../models");
const { verifyPassword } = require("../middlewares/passwords");
const generateJwtToken = require("../middlewares/generateJwtToken");
const router = express.Router();

router.post("/admin", async (req, res) => {
  try {
    const { email, password } = req.body;
    const existingUser = await Admin.findOne({ email });
    if (existingUser === null)
      return res.status(400).json({ message: "User Not found" });

    const isValidPassword = await verifyPassword(
      password,
      existingUser.password
    );

    if (!isValidPassword)
      return res.status(400).json({ message: "Invalid Login" });

    const jwtToken = await generateJwtToken(email, "admin");
    return res.status(200).json({ jwtToken });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post("/user", async (req, res) => {
  try {
    const { email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser === null)
      return res.status(400).json({ message: "User Not found" });

    const isValidPassword = await verifyPassword(
      password,
      existingUser.password
    );

    if (!isValidPassword)
      return res.status(400).json({ message: "Invalid Login" });

    const jwtToken = await generateJwtToken(email, "user");
    return res.status(200).json({ jwtToken });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
