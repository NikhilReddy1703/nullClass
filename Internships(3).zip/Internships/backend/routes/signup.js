const express = require("express");
const router = express.Router();
const { User } = require("../models");
const { hashPassword } = require("../middlewares/passwords");
const { sendSuccessfullSignUpMail } = require("../controllers/otpCenter");

router.post("/", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User Already Exists" });
    }

    const hashedPassword = await hashPassword(password);
    const newUser = new User({
      username,
      email,
      password: hashedPassword,
      role: "user",
    });

    await newUser.save();
    await sendSuccessfullSignUpMail(email);
    res.status(200).json({ message: "Successfully Registered.." });
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
