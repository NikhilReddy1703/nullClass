const express = require("express");
const router = express.Router();
const {
  verifyUserToken,
  verifyAdminToken,
} = require("../middlewares/verifyToken");
const {
  getAdminProfile,
  getUserProfile,
  updateAdminProfile,
  updateUserProfile,
} = require("../controllers/profiles");
const {
  changeAdminPassword,
  changeUserPassword,
} = require("../controllers/changePassword");

router.get("/admin", verifyAdminToken, getAdminProfile);
router.get("/user", verifyUserToken, getUserProfile);

router.put("/admin", verifyAdminToken, updateAdminProfile);
router.put("/user", verifyUserToken, updateUserProfile);

router.put("/admin/change-password", verifyAdminToken, changeAdminPassword);
router.put("/user/change-password", verifyUserToken, changeUserPassword);

module.exports = router;
