const express = require("express");
const cors = require("cors");
const connectMongoDB = require("./connection");
const routes = require("./routes");

const app = express();
app.use(express.json());
app.use(cors());
app.use(routes);

//mongodb://localhost:27017/nullclass

const startServer = () => {
  const url =
    "mongodb+srv://nullclassInternhip:LIpTI6evYLM95GNr@cluster0.ppll358.mongodb.net/?retryWrites=true&w=majority";
  connectMongoDB(url);
  app.listen(8000, () => {
    console.log("Server is running on port 8000");
  });
};

startServer();
