const jwt = require("jsonwebtoken");
const generateJwtToken = (email, role) => {
  const payload = {
    email,
    role,
  };
  const jwtToken = jwt.sign(payload, "Nithin");
  return jwtToken;
};

module.exports = generateJwtToken;
