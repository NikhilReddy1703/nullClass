const jwt = require("jsonwebtoken");

const verifyAdminToken = async (req, res, next) => {
  const authorization = req.headers["authorization"];
  if (!authorization) {
    return res.status(400).send("Authorization Error");
  }

  const jwtToken = authorization.split(" ")[1];

  if (!jwtToken) return res.status(400).send("Authentication Error");
  try {
    const payload = jwt.verify(jwtToken, "Nithin");
    const { email, role } = payload;
    if (role !== "admin") return;
    req.email = email;
    next();
  } catch (error) {
    res.status(400).json({ message: "Invalid token." });
  }
};

const verifyUserToken = async (req, res, next) => {
  const authorization = req.headers["authorization"];

  if (!authorization) {
    return res.status(400).send("Authorization Error");
  }

  const jwtToken = authorization.split(" ")[1];

  if (!jwtToken) return res.status(400).send("Authentication Error");
  try {
    const payload = jwt.verify(jwtToken, "Nithin");
    const { email, role } = payload;
    if (role !== "user") return;
    req.email = email;

    next();
  } catch (error) {
    res.status(400).json({ message: "Invalid token." });
  }
};

const verifyAdminOrUserToken = async (req, res, next) => {
  const authorization = req.headers["authorization"];

  if (!authorization) {
    return res.status(400).send("Authorization Error");
  }

  const jwtToken = authorization.split(" ")[1];

  if (!jwtToken) return res.status(400).send("Authentication Error");
  try {
    const payload = jwt.verify(jwtToken, "Nithin");
    const { email, role } = payload;

    if (role == "admin" || role == "user") req.email = email;

    next();
  } catch (error) {
    res.status(400).json({ message: "Invalid token." });
  }
};

module.exports = {
  verifyAdminToken,
  verifyUserToken,
  verifyAdminOrUserToken,
};
