const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true },
  password: { type: String },
  role: { type: String, default: "user" },
  authProvider: { type: String, default: "local" },
  registeredCourses: { type: Array, required: false },
  freeProject: { type: Number, default: 1 },
});

const User = mongoose.model("User", userSchema);

module.exports = User;
