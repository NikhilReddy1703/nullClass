const mongoose = require("mongoose");

const coursesSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, requried: false },
  domain: { type: String, required: true },
  video: { type: String, required: true },
  courseAddedDate: { type: Date, default: Date.now },
  category: { type: String, required: true },
});

const Courses = mongoose.model("courses", coursesSchema);

module.exports = Courses;
