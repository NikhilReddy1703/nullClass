const Admin = require("./admin");
const User = require("./user");
const Courses = require("./courses");

module.exports = {
  Admin,
  User,
  Courses,
};
