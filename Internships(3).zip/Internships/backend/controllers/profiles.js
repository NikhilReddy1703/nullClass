const { Admin, User } = require("../models");

const getAdminProfile = async (req, res) => {
  try {
    const { email } = req;
    const profile = await Admin.findOne({ email });
    return res.status(200).send({ profile });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const getUserProfile = async (req, res) => {
  try {
    const { email } = req;
    const profile = await User.findOne({ email });
    return res.status(200).send({ profile });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const updateUserProfile = async (req, res) => {
  try {
    const { email } = req;
    const { username } = req.body;

    await User.updateOne({ email }, { $set: { username } });

    return res.status(200).send({ message: "Profile Updated" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const updateAdminProfile = async (req, res) => {
  try {
    const { email } = req;
    const { username } = req.body;
    await Admin.updateOne({ email }, { $set: { username } });
    return res.status(200).send({ message: "Profile Updated" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAdminProfile,
  getUserProfile,
  updateUserProfile,
  updateAdminProfile,
};
