const { User, Admin } = require("../models");
const { hashPassword, verifyPassword } = require("../middlewares/passwords");

const changePassword = (Model) => async (req, res) => {
  try {
    const { email } = req;
    const { oldPassword, newPassword } = req.body;
    const user = await Model.findOne({ email });
    const isMatch = await verifyPassword(oldPassword, user.password);
    if (!isMatch) return res.status(401).json({ message: "Invalid password" });

    const hashedPassword = await hashPassword(newPassword);

    await Model.updateOne(
      { email },
      {
        $set: {
          password: hashedPassword,
        },
      }
    );
    res.status(200).json({ message: "Password updated successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const changeAdminPassword = changePassword(Admin);
const changeUserPassword = changePassword(User);

module.exports = { changeAdminPassword, changeUserPassword };
