const { Courses } = require("../models");

const getCourses = async (req, res) => {
  try {
    const courses = await Courses.find();
    return res.status(200).json({ courses });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const addCourses = async (req, res) => {
  try {
    const { title, type, domain, video, description, category } = req.body;
    const newCourse = new Courses({
      title,
      type,
      domain,
      video,
      description,
      category,
    });
    await newCourse.save();
    return res.status(200).json({ message: "Course added successfully" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const editCourse = async (req, res) => {
  try {
    const { courseId } = req.params;
    const { title, type, domain, video, description, category } = req.body;
    await Courses.updateOne(
      { _id: courseId },
      { $set: { title, type, domain, video, description, category } }
    );
    return res.status(200).json({ message: "Course edited successfully" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const deleteCourse = async (req, res) => {
  try {
    const { courseId } = req.params;
    await Courses.deleteOne({ _id: courseId });
    return res.status(200).json({ message: "Course deleted successfully" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getCourses,
  addCourses,
  editCourse,
  deleteCourse,
};
