const { User, Admin } = require("../models");
const nodemailer = require("nodemailer");
const otpStore = new Map();
const { hashPassword } = require("../middlewares/passwords");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "your mail",
    pass: "password",
  },
});

const generateOtp = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

const getOtp = async (req, res) => {
  try {
    const { email, role } = req.body;

    if (role === "user") {
      const user = await User.findOne({ email });
      if (!user) return res.status(400).json({ message: "User Not Found" });
    } else if (role === "admin") {
      const admin = await Admin.findOne({ email });
      if (!admin) return res.status(400).json({ message: "Admin Not Found" });
    } else {
      return res.status(400).json({ message: "Invalid Role" });
    }

    const otp = generateOtp();
    otpStore.set(email, otp);

    const mailOptions = {
      from: "your mail",
      to: email,
      subject: "Password Reset",
      text: `Password reset Code: ${otp}`,
    };

    await transporter.sendMail(mailOptions);
    res.status(200).json({ message: "OTP sent successfully", OTP: otp });
  } catch (error) {
    console.error("Error sending email: ", error.message);
    res.status(500).json({ message: error.message });
  }
};

const changePassword = async (req, res) => {
  try {
    const { email, newPassword, role } = req.body;
    if (role === "user") {
      const hashedPassword = await hashPassword(newPassword);
      await User.updateOne({ email }, { $set: { password: hashedPassword } });
      return res.status(200).json({ message: "Password updated successfully" });
    } else if (role === "admin") {
      const hashedPassword = await hashPassword(newPassword);
      await Admin.updateOne({ email }, { $set: { password: hashedPassword } });
      return res.status(200).json({ message: "Password updated successfully" });
    } else {
      return res.status(400).json({ message: "Invalid Role" });
    }
  } catch (error) {
    console.error("Error changing password: ", error.message);
    res.status(500).json({ message: error.message });
  }
};

const sendSuccessfullSignUpMail = async (email) => {
  try {
    const mailOptions = {
      from: "your mail",
      to: email,
      subject: "Successful SignUp",
      text: "You have successfully signed up!",
    };
    await transporter.sendMail(mailOptions);
    console.log("Sign-up email sent successfully.");
  } catch (error) {
    console.log("Error sending email: ", error.message);
  }
};

module.exports = {
  getOtp,
  sendSuccessfullSignUpMail,
  changePassword,
};
