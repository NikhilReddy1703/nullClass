import { useEffect, useState } from "react";
import Cookies from "js-cookie";
import ChangePasswordComponent from "./ChangePassword";

const Profile = ({ user }) => {
  const [profile, setProfile] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ username: "", email: "" });
  const jwtToken = Cookies.get("jwtToken");

  useEffect(() => {
    const getProfile = async () => {
      const url = `https://null-class-two.vercel.app/profile/${user}`;
      const options = {
        headers: {
          authorization: `Bearer ${jwtToken}`,
        },
      };
      const response = await fetch(url, options);
      if (response.ok) {
        const { profile } = await response.json();
        setProfile(profile);
        setFormData({ username: profile.username, email: profile.email });
      } else {
        console.log("error");
      }
    };
    getProfile();
  }, [user, jwtToken]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleEditProfile = async (e) => {
    e.preventDefault();
    const url = `https://null-class-two.vercel.app/profile/${user}`;
    const options = {
      method: "PUT",
      headers: {
        authorization: `Bearer ${jwtToken}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(formData),
    };
    const response = await fetch(url, options);
    if (response.ok) {
      await response.json();
      setIsEditing(false);
      window.location.reload();
    } else {
      const { message } = await response.json();
      console.log(message);
    }
  };

  return (
    <main className="min-h-screen flex flex-col justify-center items-center bg-gray-100 py-10">
      <div className="mb-4 bg-white shadow-lg rounded-lg p-6 max-w-md w-full">
        <h1 className="text-2xl font-bold text-center mb-6">Profile</h1>
        <div className="space-y-4">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-blue-500">
              <img
                src="https://via.placeholder.com/100"
                alt="User"
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="text-xl font-semibold mt-4">{profile.username}</h2>
          </div>
          <div className="text-center">
            <p className="text-gray-700">
              <span className="font-semibold">Email:</span> {profile.email}
            </p>
            {user === "user" && (
              <p className="text-gray-700">
                <span className="font-semibold">Registered Courses:</span>{" "}
                {profile.registeredCourses?.length || 0}
              </p>
            )}
          </div>
          {!isEditing && (
            <div className="flex justify-center mt-6">
              <button
                onClick={() => setIsEditing(true)}
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
              >
                Edit Profile
              </button>
            </div>
          )}
          {isEditing && (
            <form onSubmit={handleEditProfile} className="space-y-4 mt-6">
              <div>
                <label
                  htmlFor="username"
                  className="block text-gray-700 font-semibold"
                >
                  Username
                </label>
                <input
                  type="text"
                  id="username"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  className="mt-1 block w-full p-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label
                  htmlFor="email"
                  className="block text-gray-700 font-semibold"
                >
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="mt-1 block w-full p-2 border border-gray-300 rounded-md"
                />
              </div>
              <div className="flex justify-center space-x-4">
                <button
                  type="submit"
                  className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
      <ChangePasswordComponent user={user} />
    </main>
  );
};

export default Profile;
