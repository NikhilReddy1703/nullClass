// import { useAuth0 } from "@auth0/auth0-react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import UserHome from "./pages/User/UserHome.jsx";
import AdminHome from "./pages/Admin/AdminHome.jsx";
import SignUp from "./pages/SignUp.jsx";
import AdminProfile from "./pages/Admin/AdminProfile.jsx";
import Home from "./pages/Home.jsx";
import ProtectedRoute from "./protected/ProtectedRoute.jsx";
import CheckAlreadyLogged from "./protected/CheckAlreadyLogged.jsx";
import UserProfile from "./pages/User/UserProfile.jsx";
import CoursesPage from "./pages/User/CoursesPage.jsx";
import AdminLogin from "./pages/AdminLogin.jsx";
import UserLogin from "./pages/UserLogin.jsx";
import Internships from "./pages/Internships.jsx";
import MyCourses from "./pages/User/MyCourses.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/admin-login"
          element={<CheckAlreadyLogged component={AdminLogin} />}
        />
        <Route
          path="/user-signup"
          element={<CheckAlreadyLogged component={SignUp} />}
        />

        <Route
          path="/user-login"
          element={<CheckAlreadyLogged component={UserLogin} />}
        />
        <Route
          path="/signup"
          element={<CheckAlreadyLogged component={SignUp} />}
        />

        <Route path="/" element={<CheckAlreadyLogged component={Home} />} />
        <Route
          path="/internships"
          element={<CheckAlreadyLogged component={Internships} />}
        />

        <Route
          path="/admin"
          element={
            <ProtectedRoute component={AdminHome} requiredRole="admin" />
          }
        />
        <Route
          path="/admin/profile"
          element={
            <ProtectedRoute component={AdminProfile} requiredRole="admin" />
          }
        />

        <Route
          path="/user"
          element={<ProtectedRoute component={UserHome} requiredRole="user" />}
        />
        <Route
          path="/courses/:category"
          element={
            <ProtectedRoute component={CoursesPage} requiredRole="user" />
          }
        />
        <Route
          path="/user/profile"
          element={
            <ProtectedRoute component={UserProfile} requiredRole="user" />
          }
        />
        <Route
          path="/user/my-courses"
          element={<ProtectedRoute component={MyCourses} requiredRole="user" />}
        />

        <Route path="/forgot-password" element={<ForgotPassword />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
