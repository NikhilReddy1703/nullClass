import { useEffect, useState } from "react";
import Header from "../../components/Header";
import { adminHeaderContent } from "../../store/HeaderContents";
import Cookies from "js-cookie";

const AdminHome = () => {
  const [title, setTitle] = useState("");
  const [video, setVideo] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [domain, setDomain] = useState("");
  const [courses, setCourses] = useState([]);
  const jwtToken = Cookies.get("jwtToken");

  useEffect(() => {
    getCourses();
  }, []);

  const getCourses = async () => {
    const url = "https://null-class-two.vercel.app/courses";
    const options = {
      method: "GET",
      headers: {
        authorization: `Bearer ${jwtToken}`,
        "content-type": "application/json",
      },
    };
    const response = await fetch(url, options);
    if (response.ok) {
      const { courses } = await response.json();
      setCourses(courses);
    } else {
      const msg = await response.json();
      console.log(msg);
    }
  };

  const handleAddCourse = async (e) => {
    e.preventDefault();
    if (title && video && description && domain && category) {
      const url = "https://null-class-two.vercel.app/courses";
      const options = {
        method: "POST",
        headers: {
          authorization: `Bearer ${jwtToken}`,
          "content-type": "application/json",
        },
        body: JSON.stringify({
          title,
          domain,
          video,
          description,
          category,
        }),
      };
      const response = await fetch(url, options);
      if (response.ok) {
        const { message } = await response.json();
        alert(message);
        getCourses();
      } else {
        const { message } = await response.json();
        console.log(message);
      }
      setTitle("");
      setVideo("");
      setDescription("");
      setDomain("");
      setCategory("");
    }
  };

  return (
    <>
      <Header headerContent={adminHeaderContent} />
      <div className="p-8 bg-gray-100 min-h-screen">
        <h1 className="text-2xl font-bold mb-6">Admin Panel - Add Courses</h1>
        <form
          onSubmit={handleAddCourse}
          className="bg-white p-6 rounded-lg shadow-md mb-6"
        >
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">Course Title:</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">Category :</label>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">Video URL:</label>
            <input
              type="text"
              value={video}
              onChange={(e) => setVideo(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">Description:</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">Domain:</label>
            <input
              type="text"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors duration-300"
          >
            Add Course
          </button>
        </form>
        <h2 className="text-xl font-bold mb-4">Courses List</h2>
        <ul className="bg-white p-6 rounded-lg shadow-md">
          {courses.map((course, index) => (
            <li key={index} className="mb-4">
              <div>
                <span className="font-semibold">Title:</span> {course.title}
              </div>
              <div>
                <span className="font-semibold">Type:</span> {course.type}
              </div>
              <div>
                <span className="font-semibold">Description:</span>{" "}
                {course.description}
              </div>
              <div>
                <span className="font-semibold">Domain:</span> {course.domain}
              </div>
              <div>
                <span className="font-semibold">Cost:</span> ${course.cost}
              </div>
              <div>
                <span className="font-semibold">Video URL:</span>
                <a
                  href={course.video}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:underline"
                >
                  {course.video}
                </a>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default AdminHome;
