import React from "react";
import Header from "../../components/Header";
import { adminHeaderContent } from "../../store/HeaderContents";
import Profile from "../../components/Profile";

const AdminProfile = () => {
  return (
    <>
      <Header headerContent={adminHeaderContent} />
      <Profile user="admin" />
    </>
  );
};

export default AdminProfile;
