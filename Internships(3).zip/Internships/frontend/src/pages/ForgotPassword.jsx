import { Button } from "@mui/material";
import { useState } from "react";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("user");
  const [msg, setMsg] = useState("");
  const [otp, setOtp] = useState(null);
  const [otpEntered, setOtpEntered] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);

  const sendEmailBtn = async () => {
    const url = `https://null-class-two.vercel.app/forgot-password`;
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, role }),
    };
    try {
      const response = await fetch(url, options);
      if (response.ok) {
        const { message, OTP } = await response.json();
        setOtp(OTP);
        alert(message);
      } else {
        const { message } = await response.json();
        alert(message);
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const submitOtp = (event) => {
    event.preventDefault();
    if (otpEntered === otp) {
      setShowNewPassword(true);
    } else {
      alert("OTP Incorrect");
    }
  };

  const submitNewPassword = async (event) => {
    event.preventDefault();
    const url = `https://null-class-two.vercel.app/forgot-password/change-password`;
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, role, newPassword }),
    };
    try {
      const response = await fetch(url, options);
      if (response.ok) {
        const { message } = await response.json();
        alert(message);
        setShowNewPassword(false);
        setNewPassword("");
        setOtp(null);
        setMsg("");
        setOtpEntered("");
        setEmail("");
        setRole("user");
      } else {
        const { message } = await response.json();
        alert(message);
      }
    } catch (error) {
      alert("An error occurred while changing password: " + error.message);
    }
  };

  return (
    <main className="h-[100vh] flex justify-center items-center">
      <div className="flex flex-col space-y-4 shadow-md p-6 max-w-[350px]">
        <h1 className="font-bold text-xl text-center">Forgot Password</h1>
        <select
          id="role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="h-10 p-3 border border-gray-300 rounded"
        >
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>
        <input
          type="email"
          id="email"
          placeholder="Enter Your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="h-10 p-3 border border-gray-300 rounded"
          required
        />
        <Button variant="contained" type="button" onClick={sendEmailBtn}>
          Send OTP Email
        </Button>

        <form onSubmit={submitOtp}>
          <input
            type="number"
            id="otp"
            placeholder="Enter the OTP sent to your email"
            value={otpEntered}
            onChange={(e) => setOtpEntered(e.target.value)}
            className="h-10 p-3 border border-gray-300 rounded"
            required
          />
          <Button variant="contained" type="submit">
            Submit OTP
          </Button>
        </form>

        {showNewPassword && (
          <>
            <input
              type="password"
              placeholder="New Password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="h-10 p-3 border border-gray-300 rounded"
              required
            />
            <Button
              variant="contained"
              type="button"
              onClick={submitNewPassword}
            >
              Confirm
            </Button>
          </>
        )}
        <p className="text-red-500">{msg}</p>
      </div>
    </main>
  );
};

export default ForgotPassword;
