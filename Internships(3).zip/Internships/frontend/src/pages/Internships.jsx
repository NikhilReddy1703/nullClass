import { useState, useEffect } from "react";
import Header from "../components/Header";
import { homeHeaderContent } from "../store/HeaderContents";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";

const Internships = () => {
  const [courses, setCourses] = useState([]);
  const jwtToken = Cookies.get("jwtToken");
  const navigate = useNavigate();

  useEffect(() => {
    getCourses();
  }, []);

  const getCourses = async () => {
    const url = "https://null-class-two.vercel.app/courses";
    const options = {
      method: "GET",
      headers: {
        authorization: `Bearer ${jwtToken}`,
        "content-type": "application/json",
      },
    };
    const response = await fetch(url, options);
    if (response.ok) {
      const { courses } = await response.json();
      setCourses(courses);
    } else {
      const { message } = await response.json();
      console.log(message);
    }
  };

  const renderCourses = (internships) => (
    <div className="pt-[400px] grid grid-cols-1 gap-6 w-full max-w-2xl md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
      {internships.map((course, index) => (
        <div key={index} className="bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-2">{course.title}</h2>
          <p className="text-gray-700 mb-2">{course.description}</p>
          <p className="text-gray-700 mb-2">
            <strong>Project:</strong> {course.project}
          </p>
          <p className="text-gray-700 mb-2">
            <strong>Domain:</strong> {course.domain}
          </p>
          <p className="text-gray-700 mb-2">
            <strong>Fee:</strong> {course.category}
          </p>
          <Button onClick={() => navigate("/user-signup")} variant="contained">
            Register
          </Button>
        </div>
      ))}
    </div>
  );

  return (
    <>
      <Header headerContent={homeHeaderContent} />
      <main className="h-screen w-full flex justify-center items-center">
        {renderCourses(courses)}
      </main>
    </>
  );
};

export default Internships;
