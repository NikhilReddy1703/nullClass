import Header from "../../components/Header";
import { userHeaderContent } from "../../store/HeaderContents";
import Profile from "../../components/Profile";

const UserProfile = () => {
  return (
    <>
      <Header headerContent={userHeaderContent} />
      <Profile user="user" />
    </>
  );
};

export default UserProfile;
