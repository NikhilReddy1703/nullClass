import { useLocation } from "react-router-dom";
import Header from "../../components/Header";
import { userHeaderContent } from "../../store/HeaderContents";
import { useState } from "react";
import { Button } from "@mui/material";
import Cookies from "js-cookie";

const CoursesPage = () => {
  const location = useLocation();
  const { internships, limit, freeInternship } = location.state || {
    internships: [],
    limit: 0,
    freeInternship: false,
  };
  const [selectedCoursesForBuy, setSelectedCoursesForBuy] = useState([]);
  const jwtToken = Cookies.get("jwtToken");

  const toggleSelect = (course) => {
    const selectedIndex = selectedCoursesForBuy.indexOf(course._id);
    if (selectedIndex === -1) {
      if (selectedCoursesForBuy.length >= limit) {
        alert("You can only select a maximum of " + limit + " courses.");
        return;
      }
      setSelectedCoursesForBuy([...selectedCoursesForBuy, course._id]);
    } else {
      setSelectedCoursesForBuy(
        selectedCoursesForBuy.filter((_id) => _id !== course._id)
      );
    }
  };

  const registerSelectedCourses = async () => {
    try {
      const url = "https://null-class-two.vercel.app/courses/register";
      const options = {
        method: "POST",
        headers: {
          authorization: `Bearer ${jwtToken}`,
          "content-type": "application/json",
        },
        body: JSON.stringify({
          selectedCourses: selectedCoursesForBuy,
          freeInternship,
        }),
      };
      const response = await fetch(url, options);
      if (response.ok) {
        const { message } = await response.json();
        alert(message);
        setSelectedCoursesForBuy([]);
      } else {
        const { message } = await response.json();
        alert(message);
      }
    } catch (error) {
      alert("An error occurred while registering courses: " + error.message);
    }
  };

  const handleCheckboxChange = (course) => (event) => {
    toggleSelect(course);
  };

  const renderCourses = (internships) => (
    <div className="grid grid-cols-1 gap-6 w-full max-w-2xl md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
      {internships.map((course, index) => (
        <div key={index} className="bg-white p-4 rounded-lg shadow-md">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold mb-2">{course.title}</h2>
            <input
              type="checkbox"
              name="course"
              checked={selectedCoursesForBuy.includes(course._id)}
              onChange={handleCheckboxChange(course)}
              className="form-checkbox h-5 w-5 text-blue-600"
            />
          </div>
          <p className="text-gray-700 mb-2">{course.description}</p>
          <p className="text-gray-700 mb-2">
            <strong>Project:</strong> {course.project}
          </p>
          <p className="text-gray-700 mb-2">
            <strong>Domain:</strong> {course.domain}
          </p>
          <p className="text-gray-700 mb-2">
            <strong>Fee:</strong> {course.category}
          </p>
        </div>
      ))}
    </div>
  );

  return (
    <>
      <Header headerContent={userHeaderContent} />
      <main className="pt-[90px] flex flex-col items-center p-4 min-h-screen bg-gray-100">
        <h1 className="text-2xl font-bold mb-6 text-center">
          Internship Opportunities
        </h1>
        {renderCourses(internships)}
        {selectedCoursesForBuy.length <= limit && (
          <Button
            onClick={registerSelectedCourses}
            variant="contained"
            sx={{ marginTop: 3 }}
          >
            Register
          </Button>
        )}
      </main>
    </>
  );
};

export default CoursesPage;
