import Header from "../../components/Header";
import { userHeaderContent } from "../../store/HeaderContents";
import Cookies from "js-cookie";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const UserHome = () => {
  const [courses, setCourses] = useState([]);
  const jwtToken = Cookies.get("jwtToken");
  const navigate = useNavigate();

  useEffect(() => {
    getCourses();
  }, []);

  const getCourses = async () => {
    const url = "https://null-class-two.vercel.app/courses";
    const options = {
      method: "GET",
      headers: {
        authorization: `Bearer ${jwtToken}`,
        "content-type": "application/json",
      },
    };
    const response = await fetch(url, options);
    if (response.ok) {
      const { courses } = await response.json();
      setCourses(courses);
    } else {
      const { message } = await response.json();
      console.log(message);
    }
  };

  const freeInternships = courses.filter(
    (course) => course.category === "free"
  );

  const paidInternships = courses.filter(
    (course) => course.category === "paid"
  );

  console.log(paidInternships);

  const renderInternships = (title, internships, fee, limit) => (
    <div className="bg-white p-6 rounded-lg shadow-md text-center">
      <h1 className="text-xl font-semibold mb-4">{title}</h1>
      <p className="text-gray-700 mb-4">
        {fee === 0
          ? "Get only one internship opportunity"
          : `Get ${internships.length} exciting internship opportunities`}
      </p>
      <button
        onClick={() =>
          fee === 0
            ? navigate(`/courses/free`, {
                state: {
                  internships: freeInternships,
                  limit,
                  freeInternship: true,
                },
              })
            : navigate(`/courses/paid`, {
                state: {
                  internships: paidInternships,
                  limit,
                  freeInternships: false,
                },
              })
        }
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        {fee === 0 ? "Get for free" : `Get for $${fee}`}
      </button>
    </div>
  );

  return (
    <>
      <Header headerContent={userHeaderContent} />
      <main className="pt-[100px] flex flex-col items-center p-4 min-h-screen bg-gray-100">
        <h1 className="text-2xl font-bold mb-6 text-center">
          Hello, we are providing exciting Internship Opportunities
        </h1>
        <div className="grid grid-cols-1 gap-6 w-full max-w-2xl md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 mb-6">
          {renderInternships("Free Internships", freeInternships, 0, 1)}
          {renderInternships(
            "Silver Plan Internships",
            paidInternships,
            100,
            3
          )}
          {renderInternships(
            "Bronze Plan Internships",
            paidInternships,
            300,
            5
          )}
          {renderInternships(
            "Gold Plan Internships",
            paidInternships,
            1000,
            999999
          )}
        </div>
      </main>
    </>
  );
};

export default UserHome;
