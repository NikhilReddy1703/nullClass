import { useEffect, useState } from "react";
import Header from "../../components/Header";
import { userHeaderContent } from "../../store/HeaderContents";
import Cookies from "js-cookie";

const MyCourses = () => {
  const jwtToken = Cookies.get("jwtToken");
  const [myCourses, setMyCourses] = useState([]);

  useEffect(() => {
    getMyCourses();
  }, []);

  const getMyCourses = async () => {
    const url = "https://null-class-two.vercel.app/courses/registered";
    const options = {
      headers: {
        authorization: `Bearer ${jwtToken}`,
      },
    };
    const response = await fetch(url, options);
    if (response.ok) {
      const { courses } = await response.json();
      setMyCourses(courses);
    } else {
      const { message } = response.json();
      console.log(message);
    }
  };

  return (
    <>
      <Header headerContent={userHeaderContent} />
      <main className="pt-[90px] flex flex-col items-center p-4 min-h-screen bg-gray-100">
        {myCourses.length > 0 ? (
          <div className="w-full max-w-2xl bg-white p-6 rounded-lg shadow-md">
            <h1 className="text-2xl font-bold mb-4 text-center">My Courses</h1>
            <ul className="space-y-4">
              {myCourses.map((course) => (
                <li key={course._id} className="p-4 bg-gray-200 rounded-md">
                  <p>{course.title}</p>
                  <p>{course.description}</p>
                  <p>{course.domain}</p>
                  <p>{course.video}</p>
                  <p>{course.category}</p>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="text-center text-xl text-gray-600 mt-20">
            No courses registered yet
          </div>
        )}
      </main>
    </>
  );
};

export default MyCourses;
