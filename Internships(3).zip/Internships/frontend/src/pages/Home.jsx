import Header from "../components/Header";
import { homeHeaderContent } from "../store/HeaderContents";

const Home = () => {
  return (
    <>
      <Header headerContent={homeHeaderContent} />
      <div className="bg-gray-100 min-h-screen">
        <section className="py-20 bg-blue-500 text-white text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              Find Your Next Internship
            </h1>
            <p className="text-lg md:text-xl mb-8">
              Explore exciting internship opportunities that match your skills
              and interests.
            </p>
            <a
              href="/internships"
              className="bg-white text-blue-500 hover:bg-blue-600 py-3 px-8 rounded-full inline-block font-semibold transition duration-300"
            >
              View Internships
            </a>
          </div>
        </section>
        <section className="py-16">
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <h2 className="text-xl font-semibold mb-4">
                  Wide Range of Internships
                </h2>
                <p className="text-gray-700">
                  Discover internships in various fields including technology,
                  marketing, finance, and more.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <h2 className="text-xl font-semibold mb-4">Flexible Plans</h2>
                <p className="text-gray-700">
                  Choose from free, affordable, and premium internship plans
                  tailored to your needs.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <h2 className="text-xl font-semibold mb-4">
                  Career Development
                </h2>
                <p className="text-gray-700">
                  Gain valuable experience and skills that will boost your
                  career prospects.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="py-16 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Start Your Journey?
            </h2>
            <p className="text-lg mb-8">
              Sign up today and begin exploring internship opportunities that
              match your goals.
            </p>
            <p className="bg-blue-500 text-white hover:bg-blue-600 py-3 px-8 rounded-full inline-block font-semibold transition duration-300">
              Get Started
            </p>
          </div>
        </section>
        <footer className="bg-gray-800 text-white text-center py-8">
          <p>&copy; 2024 Your Internship Provider. All rights reserved.</p>
        </footer>
      </div>
    </>
  );
};

export default Home;
