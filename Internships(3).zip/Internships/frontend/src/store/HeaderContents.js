export const adminHeaderContent = [
  {
    title: "Profile",
    link: "/admin/profile",
  },
  {
    title: "Logout",
    link: "/logout",
  },
];

export const userHeaderContent = [
  {
    title: "Home",
    link: "/user",
  },
  {
    title: "Profile",
    link: "/user/profile",
  },
  {
    title: "My-Courses",
    link: "/user/my-courses",
  },
  {
    title: "Logout",
    link: "/logout",
  },
];

export const homeHeaderContent = [
  {
    title: "Admin",
    link: "/admin-login",
  },
  {
    title: "User",
    link: "/user-login",
  },
];
